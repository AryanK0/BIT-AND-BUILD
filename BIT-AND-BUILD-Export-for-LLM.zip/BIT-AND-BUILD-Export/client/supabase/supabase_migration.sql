-- ============================================
-- BIT & BUILD Hackathon — Supabase Schema
-- Run this in: Supabase Dashboard → SQL Editor
-- ============================================

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- TEAMS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS teams (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  team_name TEXT NOT NULL,
  leader_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  leader_email TEXT NOT NULL,
  leader_name TEXT NOT NULL,
  college TEXT,
  project_title TEXT,
  project_description TEXT,
  tech_stack TEXT,
  github_link TEXT,
  demo_link TEXT,
  submission_status TEXT DEFAULT 'not_submitted' CHECK (submission_status IN ('not_submitted', 'submitted')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- TEAM MEMBERS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS team_members (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  team_id UUID REFERENCES teams(id) ON DELETE CASCADE,
  member_name TEXT NOT NULL,
  member_email TEXT,
  member_role TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- SCORES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS scores (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  team_id UUID REFERENCES teams(id) ON DELETE CASCADE,
  judge_email TEXT NOT NULL,
  innovation INT DEFAULT 0 CHECK (innovation >= 0 AND innovation <= 10),
  technical INT DEFAULT 0 CHECK (technical >= 0 AND technical <= 10),
  design INT DEFAULT 0 CHECK (design >= 0 AND design <= 10),
  presentation INT DEFAULT 0 CHECK (presentation >= 0 AND presentation <= 10),
  comments TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(team_id, judge_email)
);

-- ============================================
-- ANNOUNCEMENTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS announcements (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  priority TEXT DEFAULT 'normal' CHECK (priority IN ('normal', 'important', 'urgent')),
  created_by TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================

-- Enable RLS on all tables
ALTER TABLE teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE team_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;

-- Teams: authenticated users can read all, but only modify their own
CREATE POLICY "Anyone can read teams" ON teams FOR SELECT USING (true);
CREATE POLICY "Users can insert own team" ON teams FOR INSERT WITH CHECK (auth.uid() = leader_id);
CREATE POLICY "Users can update own team" ON teams FOR UPDATE USING (auth.uid() = leader_id);

-- Team members: readable by all, modifiable by team leader
CREATE POLICY "Anyone can read team_members" ON team_members FOR SELECT USING (true);
CREATE POLICY "Team leaders can manage members" ON team_members FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM teams WHERE teams.id = team_members.team_id AND teams.leader_id = auth.uid()));
CREATE POLICY "Team leaders can delete members" ON team_members FOR DELETE
  USING (EXISTS (SELECT 1 FROM teams WHERE teams.id = team_members.team_id AND teams.leader_id = auth.uid()));

-- Scores: readable by all, writable by anyone (judges use hardcoded auth)
CREATE POLICY "Anyone can read scores" ON scores FOR SELECT USING (true);
CREATE POLICY "Anyone can insert scores" ON scores FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update scores" ON scores FOR UPDATE USING (true);

-- Announcements: readable by all, writable by anyone (organizers use hardcoded auth)
CREATE POLICY "Anyone can read announcements" ON announcements FOR SELECT USING (true);
CREATE POLICY "Anyone can insert announcements" ON announcements FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can delete announcements" ON announcements FOR DELETE USING (true);

-- ============================================
-- INDEXES
-- ============================================
CREATE INDEX IF NOT EXISTS idx_teams_leader_id ON teams(leader_id);
CREATE INDEX IF NOT EXISTS idx_team_members_team_id ON team_members(team_id);
CREATE INDEX IF NOT EXISTS idx_scores_team_id ON scores(team_id);
CREATE INDEX IF NOT EXISTS idx_announcements_created_at ON announcements(created_at DESC);
