import { useEffect, useRef } from 'react';
import './BackgroundEffects.css';

const BUILDINGS = [
  [3, 34, 10], [14, 48, 7], [23, 28, 13], [35, 58, 9], [46, 38, 12],
  [59, 66, 8], [69, 44, 14], [82, 54, 10], [92, 32, 7],
];

const PARTICLES = Array.from({ length: 26 }, (_, index) => ({
  left: `${(index * 37) % 100}%`,
  top: `${(index * 61) % 100}%`,
  delay: `${(index % 9) * 0.55}s`,
  duration: `${5 + (index % 6)}s`,
  size: `${2 + (index % 3)}px`,
}));

function BackgroundEffects({ variant = 'default' }) {
  const sceneRef = useRef(null);

  useEffect(() => {
    if (variant !== 'default') return undefined;

    const handlePointerMove = (event) => {
      const x = (event.clientX / window.innerWidth - 0.5) * 2;
      const y = (event.clientY / window.innerHeight - 0.5) * 2;
      sceneRef.current?.style.setProperty('--scene-x', `${x.toFixed(3)}`);
      sceneRef.current?.style.setProperty('--scene-y', `${y.toFixed(3)}`);
    };

    window.addEventListener('pointermove', handlePointerMove, { passive: true });
    return () => window.removeEventListener('pointermove', handlePointerMove);
  }, [variant]);

  return (
    <div ref={sceneRef} className={`bg-effects bg-effects--${variant}`} aria-hidden="true">
      <div className="bg-effects__city" aria-hidden="true">
        <div className="bg-effects__horizon" />
        {BUILDINGS.map(([left, height, width], index) => (
          <span
            className="bg-effects__building"
            key={index}
            style={{ '--building-left': `${left}%`, '--building-height': `${height}%`, '--building-width': `${width}%` }}
          />
        ))}
      </div>

      <div className="bg-effects__portal" aria-hidden="true">
        <span className="bg-effects__portal-ring bg-effects__portal-ring--outer" />
        <span className="bg-effects__portal-ring bg-effects__portal-ring--middle" />
        <span className="bg-effects__portal-ring bg-effects__portal-ring--inner" />
        <span className="bg-effects__portal-core" />
      </div>

      <svg className="bg-effects__web" viewBox="0 0 1200 800" preserveAspectRatio="xMidYMid slice">
        <g fill="none" stroke="currentColor" strokeWidth="1">
          <ellipse cx="760" cy="370" rx="170" ry="96" />
          <ellipse cx="760" cy="370" rx="300" ry="170" />
          <ellipse cx="760" cy="370" rx="470" ry="270" />
          <path d="M760 370 L760 -80 M760 370 L1180 80 M760 370 L1280 370 M760 370 L1150 720 M760 370 L760 850 M760 370 L340 720 M760 370 L240 370 M760 370 L350 50" />
        </g>
      </svg>

      <div className="bg-effects__speed-lines" />

      {/* Atmospheric color and comic texture */}
      <div className="bg-effects__glow bg-effects__glow--pink" />
      <div className="bg-effects__glow bg-effects__glow--purple" />
      <div className="bg-effects__glow bg-effects__glow--blue" />
      <div className="bg-effects__dots" />

      <div className="bg-effects__particles">
        {PARTICLES.map((particle, i) => (
          <span
            key={i}
            className="bg-effects__particle"
            style={{
              left: particle.left,
              top: particle.top,
              animationDelay: particle.delay,
              animationDuration: particle.duration,
              '--particle-color': ['#ef233c', '#f8f9fa', '#22d3ee', '#ffb703'][i % 4],
              '--particle-size': particle.size,
            }}
          />
        ))}
      </div>

      <svg
        className="bg-effects__strands"
        viewBox="0 0 1200 800"
        preserveAspectRatio="xMaxYMin slice"
      >
        <defs>
          <linearGradient id="strand-grad-pink" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#FF2D95" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#FF2D95" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="strand-grad-blue" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#1B9CFC" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#1B9CFC" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="strand-grad-purple" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#BE2EDD" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#BE2EDD" stopOpacity="0" />
          </linearGradient>
        </defs>
        <g fill="none" strokeWidth="1" opacity="0.5">
          <line x1="1200" y1="0" x2="400" y2="800" stroke="url(#strand-grad-pink)" className="bg-effects__strand" />
          <line x1="1200" y1="80" x2="550" y2="800" stroke="url(#strand-grad-blue)" className="bg-effects__strand" style={{animationDelay: '0.5s'}} />
          <line x1="1200" y1="180" x2="700" y2="800" stroke="url(#strand-grad-purple)" className="bg-effects__strand" style={{animationDelay: '1s'}} />
          <line x1="1200" y1="300" x2="850" y2="800" stroke="url(#strand-grad-pink)" className="bg-effects__strand" style={{animationDelay: '1.5s'}} />
          <line x1="1200" y1="440" x2="1000" y2="800" stroke="url(#strand-grad-blue)" className="bg-effects__strand" style={{animationDelay: '2s'}} />
          <path d="M 850 0 Q 650 300 730 650" stroke="url(#strand-grad-purple)" className="bg-effects__strand" style={{animationDelay: '0.8s'}} />
          <path d="M 1050 30 Q 800 280 840 640" stroke="url(#strand-grad-pink)" className="bg-effects__strand" style={{animationDelay: '1.2s'}} />
          <path d="M 950 60 Q 720 350 800 700" stroke="url(#strand-grad-blue)" className="bg-effects__strand" style={{animationDelay: '1.8s'}} />
        </g>
      </svg>
    </div>
  );
}

export default BackgroundEffects;
