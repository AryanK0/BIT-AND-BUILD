import { useEffect, useRef, useState } from 'react';
import Navbar from '../components/Navbar.jsx';
import Button from '../components/Button.jsx';
import BackgroundEffects from '../components/BackgroundEffects.jsx';
import PageContainer from '../components/PageContainer.jsx';
import './Landing.css';

const EVENT_FACTS = [
  { value: '24', unit: 'HOURS', detail: 'Non-stop coding, from keynote to final demos.', icon: '⏱️' },
  { value: '50+', unit: 'TEAMS', detail: 'Competing to build the next big thing.', icon: '👥' },
  { value: '₹50K', unit: 'PRIZES', detail: 'Cash prizes, swag, and industry mentorship.', icon: '🏆' },
  { value: '10+', unit: 'MENTORS', detail: 'Industry experts guiding your builds.', icon: '🧠' },
];

const TIMELINE = [
  { time: '9:00 AM', title: 'Check-in & Registration', desc: 'Get your badges, meet your team, fuel up.', day: 'Day 1' },
  { time: '10:00 AM', title: 'Opening Ceremony', desc: 'Keynote, rules, and problem statements revealed.', day: 'Day 1' },
  { time: '11:00 AM', title: 'Hacking Begins!', desc: 'Clock starts. Build something incredible.', day: 'Day 1' },
  { time: '2:00 PM', title: 'Mentor Round 1', desc: 'Get expert feedback on your approach.', day: 'Day 1' },
  { time: '8:00 PM', title: 'Mid-Event Check-in', desc: 'Progress updates and midnight snacks.', day: 'Day 1' },
  { time: '9:00 AM', title: 'Submissions Close', desc: 'Push your final code, polish your demo.', day: 'Day 2' },
  { time: '10:00 AM', title: 'Demo & Judging', desc: 'Present your project to the judge panel.', day: 'Day 2' },
  { time: '12:00 PM', title: 'Awards Ceremony', desc: 'Winners announced, prizes distributed!', day: 'Day 2' },
];

const PRIZES = [
  { place: '1st', prize: '₹25,000', title: 'Grand Champion', color: '#FFC312', icon: '🥇', extras: ['Trophy', 'Internship opportunity', 'Premium swag kit'] },
  { place: '2nd', prize: '₹15,000', title: 'Runner Up', color: '#1B9CFC', icon: '🥈', extras: ['Trophy', 'Tech gadgets', 'Swag kit'] },
  { place: '3rd', prize: '₹10,000', title: 'Second Runner Up', color: '#BE2EDD', icon: '🥉', extras: ['Trophy', 'Tech accessories', 'Swag kit'] },
];

const FAQS = [
  { q: 'Who can participate?', a: 'Any college student! Form a team of 2-4 members with a team leader who registers.' },
  { q: 'Do I need to know how to code?', a: 'Basic coding knowledge helps, but teams need designers, presenters, and idea people too!' },
  { q: 'What should I bring?', a: 'Your laptop, charger, student ID, and tonnes of enthusiasm. Food and drinks are on us!' },
  { q: 'Is it free to participate?', a: 'Absolutely! BIT & BUILD is completely free for all participants.' },
  { q: 'Can I participate solo?', a: 'Teams of 2-4 are required. We\'ll have a team formation session if you need teammates!' },
  { q: 'What tech stack can I use?', a: 'Anything you want! Web, mobile, AI/ML, IoT — go wild. Use whatever tools help you ship.' },
];

function Landing() {
  const [openFaq, setOpenFaq] = useState(null);
  const observerRef = useRef(null);

  // Scroll animation observer
  useEffect(() => {
    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    document.querySelectorAll('.animate-on-scroll').forEach((el) => {
      observerRef.current.observe(el);
    });

    return () => observerRef.current?.disconnect();
  }, []);

  return (
    <div className="landing">
      <Navbar />

      {/* ===== HERO ===== */}
      <section className="landing__hero">
        <BackgroundEffects />
        <PageContainer className="landing__hero-inner">
          <p className="landing__eyebrow animate-on-scroll">🕸️ Annual Student Hackathon</p>
          <h1 className="landing__headline glitch-text" data-text="BIT & BUILD">
            BIT <span className="landing__amp">&</span> BUILD
          </h1>
          <p className="landing__dimension-label animate-on-scroll">ENTER THE DIMENSION OF BUILDERS</p>
          <p className="landing__tagline animate-on-scroll">Into the Codeverse</p>
          <p className="landing__subhead animate-on-scroll">
            One campus, one night, one build. BIT & BUILD brings student teams
            together for a fast, focused sprint from idea to working demo —
            judged by people who've shipped real products.
          </p>
          <div className="landing__hero-actions animate-on-scroll">
            <Button to="/login" variant="primary">
              🚀 Register Now
            </Button>
            <Button to="/login" variant="ghost">
              Already registered? Sign in →
            </Button>
          </div>
          <div className="landing__hero-stats">
            {EVENT_FACTS.map((fact, i) => (
              <div className="landing__hero-stat animate-on-scroll" key={fact.unit} style={{ animationDelay: `${i * 0.1}s` }}>
                <span className="landing__hero-stat-icon">{fact.icon}</span>
                <span className="landing__hero-stat-value">{fact.value}</span>
                <span className="landing__hero-stat-unit">{fact.unit}</span>
              </div>
            ))}
          </div>
        </PageContainer>
      </section>

      {/* ===== ABOUT ===== */}
      <section className="landing__about" id="about">
        <PageContainer>
          <div className="landing__section-header animate-on-scroll">
            <span className="landing__section-tag">What is this?</span>
            <h2 className="landing__section-title">
              More Than a <span className="glow-text">Hackathon</span>
            </h2>
            <p className="landing__section-desc">
              BIT & BUILD isn't just about writing code — it's about turning wild ideas into
              tangible products in record time. Think of it as a creative pressure cooker.
            </p>
          </div>

          <div className="landing__about-grid">
            {[
              { title: 'Ideate', icon: '💡', desc: 'Brainstorm with your team. No idea is too wild — the multiverse has room for everything.' },
              { title: 'Build', icon: '⚡', desc: '24 hours of focused building. Ship a working prototype that solves a real problem.' },
              { title: 'Demo', icon: '🎤', desc: 'Present your creation to industry judges. Tell your story, show your impact.' },
              { title: 'Win', icon: '🏆', desc: 'Cash prizes, internship ops, and industry recognition. Your code could change everything.' },
            ].map((card, i) => (
              <div className="landing__about-card glass-card animate-on-scroll" key={card.title} style={{ animationDelay: `${i * 0.15}s` }}>
                <span className="landing__about-card-icon">{card.icon}</span>
                <h3>{card.title}</h3>
                <p>{card.desc}</p>
                <div className="landing__about-card-number">{String(i + 1).padStart(2, '0')}</div>
              </div>
            ))}
          </div>
        </PageContainer>
      </section>

      {/* ===== TIMELINE ===== */}
      <section className="landing__timeline" id="timeline">
        <PageContainer>
          <div className="landing__section-header animate-on-scroll">
            <span className="landing__section-tag">Schedule</span>
            <h2 className="landing__section-title">
              Event <span className="glow-text">Timeline</span>
            </h2>
          </div>

          <div className="landing__timeline-track">
            {TIMELINE.map((event, i) => (
              <div className={`landing__timeline-item animate-on-scroll ${i % 2 === 0 ? 'landing__timeline-item--left' : 'landing__timeline-item--right'}`}
                key={i} style={{ animationDelay: `${i * 0.1}s` }}>
                <div className="landing__timeline-dot" />
                <div className="landing__timeline-card glass-card">
                  <span className="landing__timeline-day">{event.day}</span>
                  <span className="landing__timeline-time">{event.time}</span>
                  <h3>{event.title}</h3>
                  <p>{event.desc}</p>
                </div>
              </div>
            ))}
            <div className="landing__timeline-line" />
          </div>
        </PageContainer>
      </section>

      {/* ===== PRIZES ===== */}
      <section className="landing__prizes" id="prizes">
        <PageContainer>
          <div className="landing__section-header animate-on-scroll">
            <span className="landing__section-tag">Rewards</span>
            <h2 className="landing__section-title">
              Win Big, <span className="glow-text">Build Bigger</span>
            </h2>
          </div>

          <div className="landing__prizes-grid">
            {PRIZES.map((p, i) => (
              <div className="landing__prize-card glass-card animate-on-scroll" key={p.place}
                style={{ '--prize-color': p.color, animationDelay: `${i * 0.15}s` }}>
                <span className="landing__prize-icon">{p.icon}</span>
                <span className="landing__prize-place">{p.place} Place</span>
                <span className="landing__prize-amount">{p.prize}</span>
                <span className="landing__prize-title">{p.title}</span>
                <ul className="landing__prize-extras">
                  {p.extras.map((e) => <li key={e}>✦ {e}</li>)}
                </ul>
              </div>
            ))}
          </div>
        </PageContainer>
      </section>

      {/* ===== FAQ ===== */}
      <section className="landing__faq" id="faq">
        <PageContainer>
          <div className="landing__section-header animate-on-scroll">
            <span className="landing__section-tag">Got Questions?</span>
            <h2 className="landing__section-title">
              Frequently <span className="glow-text">Asked</span>
            </h2>
          </div>

          <div className="landing__faq-list">
            {FAQS.map((faq, i) => (
              <div
                className={`landing__faq-item glass-card animate-on-scroll ${openFaq === i ? 'landing__faq-item--open' : ''}`}
                key={i}
                style={{ animationDelay: `${i * 0.08}s` }}
              >
                <button
                  className="landing__faq-question"
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  aria-expanded={openFaq === i}
                >
                  <span>{faq.q}</span>
                  <span className="landing__faq-arrow">{openFaq === i ? '−' : '+'}</span>
                </button>
                <div className="landing__faq-answer">
                  <p>{faq.a}</p>
                </div>
              </div>
            ))}
          </div>
        </PageContainer>
      </section>

      {/* ===== CTA ===== */}
      <section className="landing__cta">
        <PageContainer className="landing__cta-inner animate-on-scroll">
          <h2>Ready to Build?</h2>
          <p>Join teams from across the city. One build. One night. Infinite possibilities.</p>
          <Button to="/login" variant="primary">
            🕸️ Enter the Hackathon
          </Button>
        </PageContainer>
      </section>

      {/* ===== FOOTER ===== */}
      <footer className="landing__footer">
        <PageContainer className="landing__footer-inner">
          <div className="landing__footer-brand">
            <span className="landing__footer-wordmark">BIT <span>&amp;</span> BUILD</span>
            <p>Built by students, for students.</p>
          </div>
          <div className="landing__footer-links">
            <a href="#about">About</a>
            <a href="#timeline">Timeline</a>
            <a href="#prizes">Prizes</a>
            <a href="#faq">FAQ</a>
          </div>
          <div className="landing__footer-copy">
            <p>© 2026 BIT & BUILD. All rights reserved.</p>
          </div>
        </PageContainer>
      </footer>
    </div>
  );
}

export default Landing;
