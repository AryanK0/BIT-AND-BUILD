# BIT & BUILD

A college hackathon management platform.

**Phase 1 (current):** Frontend foundation only — landing page, login page, and
placeholder dashboards for participant / judge / organizer roles, wired up
with React Router. No backend, authentication, or database yet.

## Visual identity

BIT & BUILD is a serious, professional hackathon platform with a subtle
Spider-Verse-inspired aesthetic: dark background, red/pink accents, white
typography, and understated geometric "web strand" linework. The theme is a
visual layer, not a children's superhero skin — the platform should read as
a premium college tech event, not a cartoon.

## Project structure

```
BIT-AND-BUILD/
├── client/          React + Vite frontend (Phase 1)
│   └── src/
│       ├── components/   Reusable UI pieces (Navbar, Button, etc.)
│       ├── pages/         Route-level screens
│       ├── layouts/       Shared page/dashboard scaffolding
│       ├── styles/        Plain CSS, organized by scope
│       └── assets/        Static assets
├── server/          Reserved for Phase 2 (backend/API/auth) — empty for now
└── README.md
```

## Running the frontend

```bash
cd client
npm install
npm run dev
```

## Phase roadmap

- **Phase 1 (this phase):** Frontend foundation, routing, visual identity,
  placeholder dashboards.
- **Phase 2+:** Authentication, backend APIs, database, judging logic,
  submissions, organizer tooling. Not implemented yet.
